package agung.com;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class ListJaketAdapter extends RecyclerView.Adapter<ListJaketAdapter.ListViewHolder> {
    private ArrayList<Jaket> listJaket;

    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback){
        this.onItemClickCallback = onItemClickCallback;
    }
    public ListJaketAdapter(ArrayList<Jaket> list){ this.listJaket = list; }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row_jaket, parent, false);
        return new ListViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final ListJaketAdapter.ListViewHolder holder, int position) {
        Jaket jaket = listJaket.get(position);
        holder.tvJaket.setText(jaket.getName());
        holder.tvDetail.setText(jaket.getDetail());
        Glide.with(holder.itemView.getContext())
                .load(jaket.getPhoto())
                .apply(new RequestOptions().override(60,55))
                .into(holder.Gambar);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onItemClicked(listJaket.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return listJaket.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {
        TextView tvJaket, tvDetail;

        ImageView Gambar;

        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            tvJaket = itemView.findViewById(R.id.tv_name);
            tvDetail = itemView.findViewById(R.id.tv_detail);
            Gambar = itemView.findViewById(R.id.img_jaket);
        }
    }
    public interface OnItemClickCallback {
        void onItemClicked(Jaket data);
    }
}