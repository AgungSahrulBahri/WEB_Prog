package agung.com;

import java.util.ArrayList;

class JaketData {
    private static String[] jaketNames = {
            "bankersexclusive",
            "jaketrs",
            "jaketadidascore",
            "jaketbaseballvarsity",
            "jakethoodie",
            "jakethoodieuniqlo",
            "jaketparasut",
            "jaketpleece",
            "jaketsteigen",
            "jaketwindbreaker"
    };


    private static String[] jaketDetails = {
            "Mau mencari jaket yang masih bagus dan tahal lama? jaket ini yang cocok untuk anda",
            "Salah satu jaket yang paling hits karena memiliki design yang luar biasa adalah JaketRS. ",
            "jaket yang tak ketinggalan zaman itu jaket adidas core, ini cocok untuk anda!",
            "Ingin mencoba liburan yang anti mainstream dan selalu nyaman? Yuk, liburan pakai jaket baseball varsity",
            "jaket hoodie merupakan jaket yang banyak disukai para wanita untuk berfoto-foto.",
            "jaket hoodie uniqlo adalah jaket yang cukup terkenal dikalangan remaja. jaket ini merupakan jaket yang sudah cukup banyak disukai para remaja!",
            "mau liburan ke bukit tanpa ada rasa kedinginan? ayo, pakai jaket parasut!",
            "Nama jaket pleece tentu bukan hal asing di teling sebab ia merupakan jaket yang sangat bagus dan banyak di miliki para remaja.",
            "Salah satu jaket yang hits dikalangan anak muda karena memiliki bahan yang bisa menghangatkan badan yaitu jaket steigen",
            "Salah satu jsket yang harus kamu punya adalah jaket windbreaker. jaket ini sangan cocok dipakai semua orang "
    };
    private static int[] jaketImages ={
            R.drawable.bankersexclusive,
            R.drawable.jaketadidascore,
            R.drawable.jaketbaseballvarsity,
            R.drawable.jakethoodie,
            R.drawable.jakethoodieuniqlo,
            R.drawable.jaketparasut,
            R.drawable.jaketpleece,
            R.drawable.jaketrs,
            R.drawable.jaketsteigen,
            R.drawable.jaketwindbreaker
    };

    private static String[] Rilis = {
            "beli sekarang di shoopie!",
            "beli sekarang di shoopie!",
            "beli sekarang di shoopie!",
            "beli sekarang di shoopie!",
            "beli sekarang di shoopie!",
            "beli sekarang di shoopie!",
            "beli sekarang di shoopie!",
            "beli sekarang di shoopie!",
            "beli sekarang di shoopie!",
            "beli sekarang di shoopie!"

           };

    static ArrayList<Jaket> getListData(){
        ArrayList<Jaket> list = new ArrayList<>();
        for(int position = 0; position < jaketNames.length; position++){
            Jaket jaket = new Jaket();
            jaket.setName(jaketNames[position]);
            jaket.setRilis(Rilis[position]);
            jaket.setDetail(jaketDetails[position]);
            jaket.setPhoto(jaketImages[position]);

            list.add(jaket);
        }
        return list;
    }
}
