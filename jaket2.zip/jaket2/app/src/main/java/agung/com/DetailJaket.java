package agung.com;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailJaket extends AppCompatActivity {
    public static final String EXTRA_IMG= "extra_img";
    public static final String EXTRA_NAMAWISATA = "extra_namawisata";
    public static final String EXTRA_RILIS = "extra_rilis";
    public static final String EXTRA_PENGERTIAN= "extra_pengertian";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_jaket);

        ImageView Gambar;
        TextView tvNamaWisata, tvPengertian, tvRilis;

        Gambar = findViewById(R.id.img_wisata);
        tvNamaWisata = findViewById(R.id.tv_name);
        tvRilis = findViewById(R.id.tv_rilis);
        tvPengertian = findViewById(R.id.tv_pengertian);


        int photo = getIntent().getIntExtra(EXTRA_IMG, 0);
        String nama = getIntent().getStringExtra(EXTRA_NAMAWISATA),
                rilis = getIntent().getStringExtra(EXTRA_RILIS),
                pengertian = getIntent().getStringExtra(EXTRA_PENGERTIAN);

        Bitmap bmp = BitmapFactory.decodeResource(getResources(),photo);
        Gambar.setImageBitmap(bmp);
        tvNamaWisata.setText(nama);
        tvRilis.setText(rilis);
        tvPengertian.setText(pengertian);


    }
}
